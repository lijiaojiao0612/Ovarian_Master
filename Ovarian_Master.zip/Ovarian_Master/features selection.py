from xgboost import XGBClassifier
import scipy.stats as stats
from sklearn.utils import shuffle
from sklearn.decomposition import PCA
from sklearn.model_selection import StratifiedKFold, RepeatedKFold
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.feature_selection import f_classif
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import VarianceThreshold
import pandas as pd
import os
import warnings
from sklearn.neighbors import KNeighborsClassifier as KNN
from sklearn.linear_model import LassoCV,LogisticRegression,LogisticRegressionCV
from sklearn.linear_model import LassoCV
from sklearn.model_selection import cross_val_score
from sklearn.feature_selection import SelectKBest
from sklearn.ensemble import RandomForestClassifier as RF
from sklearn.ensemble import AdaBoostClassifier as ad
from sklearn.model_selection import cross_val_score
from sklearn import svm
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import f_classif, f_regression
from sklearn.feature_selection import SelectKBest, SelectPercentile,RFE
from sklearn.metrics import roc_auc_score, confusion_matrix, roc_curve
from sklearn.neighbors import KNeighborsClassifier as KNN
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from xgboost import plot_importance
from matplotlib import pyplot
from matplotlib.pyplot import MultipleLocator
from sklearn.model_selection import StratifiedKFold
import random
from sklearn.metrics import accuracy_score,roc_auc_score

warnings.filterwarnings('ignore')
sc = StandardScaler()
folderPath='/shuju'
data=pd.read_csv(os.path.join(folderPath,'Feature_Radiomics_BENIGN_ICC2.csv'))
train_data,test_data=train_test_split(data,test_size=0.3,random_state=20,shuffle=True)
print(train_data)

x=train_data[train_data.columns[1:]][train_data['label']==0]
y=train_data[train_data.columns[1:]][train_data['label']==1]
print(x,y)
colNames=x.columns
colNames=y.columns
x=sc.fit_transform(x)
y=sc.fit_transform(y)
print(x,y)
x=pd.DataFrame(x)
y=pd.DataFrame(y)
x.columns=colNames
y.columns=colNames
print(x,y)
index=[]
counts=0
for colName in train_data.columns[1:]:
    if stats.mannwhitneyu(x[colName], y[colName], alternative='two-sided')[1]<0.05:
       counts+=1
       index.append(colName)
print(counts)
print(len(index))
if 'label' not in index:index=['label']+index
train_data=train_data[index]
print(train_data)
x=train_data[train_data.columns[1:]]
y=train_data['label']
colNames=x.columns
x=sc.fit_transform(x)
x= pd.DataFrame(x)
x.columns = colNames
print(x,y)
alphas=np.logspace(-3,1,50)
model_LassoCV=LassoCV(alphas=alphas,cv=10,max_iter=100000).fit(x,y)
coef=pd.Series(model_LassoCV.coef_,index=x.columns)
print(model_LassoCV.alpha_)
print("Lasso picked"+str(sum(coef!=0)))
print("variables and eliminated the other"+str(sum(coef==0)))
index=coef[coef!=0].index
x=train_data[index]
print(x.head())
print(coef[coef!=0])
print(model_LassoCV.intercept_)
