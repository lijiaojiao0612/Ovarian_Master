getwd()
setwd('D:/shuju')
getwd()
library(openxlsx)
train_data<-read.xlsx('nomo_train2.xlsx')
train_data$CA_125<-factor(train_data$CA_125,levels=c(0,1),labels=c("No","Yes"))
train_data$label<-factor(train_data$label,levels=c(0,1),labels=c("oc","oec"))

dd=datadist(train_data)
options(datadist="dd")
formula1<-as.formula(label~RAD+CA_125)
fit1<-lrm(label~RAD+CA_125,data=train_data,x=T,y=T)
nom<-nomogram(fit1,
              fun=plogis,
              lp=F,
              fun.at=c(0.05,0.2,0.4,0.6,0.8,0.95),
              funlabel = 'label')
plot(nomo)