getwd()
setwd('D:/shuju')
getwd()
library(openxlsx)
library(rms)
install.packages('reader')
library(readr)
train_data<-read.xlsx('train_3.xlsx',sep =',')
train_data$label<-factor(train_data$label,levels=c(0,1),labels=c("oc","oec"))
train_data$c<-factor(train_data$CA_125,levels=c(0,1),labels=c("di","gao"))
train_data$e<-factor(train_data$Menopausal,levels=c(0,1),labels=c("fou","shi"))

formula1<-as.formula(label~RAD+CA_125)
#数据打包，只需要修改data
dd=datadist(train_data)
options(datadist="dd")

#第1种校准曲线绘制
fit1<-lrm(formula1,data=train_data,x=TRUE,y=TRUE)#拟合模型
cal1<-calibrate(fit1,method = "boot",B=40)
tiff(file = "area_female_zuhe_train.tiff",width=9.5,height=10,units="in", compression="lzw", res=600);
plot(cal1,
     xlim=c(0,1),#x轴范围
     xlab="Predicted Probability",#label
     ylab="Observed Probability",
     legend=FALSE,
     subtitles=FALSE)
abline(0,1,col="black",lty=2,lwd=1.8)#添加参考线
lines(cal1[,c("predy","calibrated.orig")],type="l",lwd=2,col="red",pch=16)
lines(cal1[,c("predy","calibrated.corrected")],type="l",lwd=2,col="blue",pch=16)
legend(0.6,0.1,              
       c("Ideal"),   
       lty=2,
       lwd=c(2,1,1),
       col=c("black"),
       bty="n",xpd=TRUE)    #legend放在横坐标0.5，纵坐标0.55的位置#"参考线","未校正的校准曲线","校正后的校准曲线

legend(0.6,0.2,              
       c("apparent"),   
       lty=1,
       lwd=c(2,1,1),
       col=c("red"),
       bty="n",xpd=TRUE)   
legend(0.6,0.3,              
       c("Bias-correced"),   
       lty=1,
       lwd=c(2,1,1),
       col=c("blue"),
       bty="n",xpd=TRUE) 
dev.off()
ckf