getwd()
setwd('D:/shuju')
getwd()
library(openxlsx)
install.packages("rmda")
library(rmda)
train_data<-read.xlsx('nomo_train2.xlsx',sep =',')
train_data$menopausal<-factor(train_data$menopausal,levels=c(0,1),labels=c("fou","shi"))
train_data$CA_125<-factor(train_data$CA_125,levels=c(0,1),labels=c("di","gao"))
Clinical<-decision_curve(label~CA_125+menopausal,
                         data=train_data,family=binomial(link='logit'),
                         thresholds=seq(0,1,by=0.01),
                         confidence.intervals=0.95,
                         study.design='cohort')
Radscore<-decision_curve(label~RAD,
                         data=train_data,family=binomial(link='logit'),
                         thresholds=seq(0,1,by=0.01),
                         confidence.intervals=0.95,
                         study.design='cohort')
Nomogram<-decision_curve(label~RAD+CA_125,
                         data=train_data,family=binomial(link='logit'),
                         thresholds=seq(0,1,by=0.01),
                         confidence.intervals=0.95,
                         study.design='cohort')
List<- list(Clinical,Radscore,Nomogram)
plot_decision_curve(List,curve.names= c('Clinical model','Radiomics signature','Radiomics nomogram'),
                    cost.benefit.axis =FALSE,col = c('red','blue','yellow'),
                    confidence.intervals =FALSE,standardize = FALSE)