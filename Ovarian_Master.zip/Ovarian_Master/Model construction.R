getwd()
setwd('D:/shuju')
getwd()
library(openxlsx)
library(rms)
train_data<-read.xlsx('train_3.xlsx')
test_data<-read.xlsx('test_3.xlsx')
train_data_1=train_data[,-1]
train_label=train_data[,1]
test_data_1=test_data[,-1]
test_label=test_data[,1]
model_log<-glm(train_label~RAD+CA_125,data=train_data_1,family = 'binomial')
model_log1<-glm(train_label~RAD,data=train_data_1,family = 'binomial')
model_log2<-glm(train_label~CA_125+Menopausal,data=train_data_1,family = 'binomial')
pred_train<-predict(model_log,type='response',newdata=train_data_1)
pred_train1<-predict(model_log1,type='response',newdata=train_data_1)
pred_train2<-predict(model_log2,type='response',newdata=train_data_1)

library('pROC')
roc_train<-roc(train_label,pred_train,levels=c(0,1))
roc_train1<-roc(train_label,pred_train1,levels=c(0,1))
roc_train2<-roc(train_label,pred_train2,levels=c(0,1))
auc1<-roc(train_label,pred_train,levels=c(0,1))
auc2<-roc(train_label,pred_train1,levels=c(0,1))
auc3<-roc(train_label,pred_train2,levels=c(0,1))
roc.test(auc1,auc2)
auc(roc_train);ci.auc(roc_train);
auc(roc_train1);ci.auc(roc_train1);
auc(roc_train2);ci.auc(roc_train2);

par(omi=c(0.4,0.4,0.4,0.4),lwd=1.6,cex.axis=1.0,cex.lab=1.5)

p1<-plot.roc(roc_train,col="indianred1",
             main="ROC curves",legacy.axes=TRUE)

p2<-plot(roc_train1,add=TRUE,col="gold1")
p3<-plot(roc_train2,add=TRUE,col="steelblue2")


legend(0.76,0.3,legend = c("Radiomics nomogram: AUC = 0.942","Clinical model: AUC = 0.831",
                           "Radiomics signature: AUC = 0.802"),text.font=2,bty="n",col = c("indianred1","steelblue2","gold1"),lty=1,lwd=3,cex=0.9)